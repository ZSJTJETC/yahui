package com.chinasofti.YaHui.enter;

import com.chinasofti.YaHui.control.Control;

public class Enter {
	public static void main(String[] args) {
		new Control().start();
	}
}
