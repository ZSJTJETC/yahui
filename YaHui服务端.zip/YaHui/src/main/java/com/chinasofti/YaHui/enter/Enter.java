package com.chinasofti.YaHui.enter;

import com.chinasofti.YaHui.control.Control;

import oracle.jdbc.driver.OracleDriver;

public class Enter 
{
    public static void main( String[] args )
    {
        new Control().start();
        
    }
}
